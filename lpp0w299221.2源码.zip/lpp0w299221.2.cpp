#include <iostream>
#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <vector>
#include <cctype>

// ==================== 全局变量 ====================
std::map<std::string, int> vars;  // 变量表
const std::string MEM_FILE = "lpp.mem";  // 记忆文件

// ==================== 记忆文件操作 ====================
// 保存变量到 lpp.mem
void saveMemory() {
    std::ofstream out(MEM_FILE);
    if (!out) return;
    for (const auto& pair : vars) {
        out << pair.first << "=" << pair.second << std::endl;
    }
    out.close();
}

// 从 lpp.mem 加载变量
void loadMemory() {
    std::ifstream in(MEM_FILE);
    if (!in) return;
    std::string line;
    while (std::getline(in, line)) {
        size_t pos = line.find('=');
        if (pos != std::string::npos) {
            std::string name = line.substr(0, pos);
            int value = std::stoi(line.substr(pos + 1));
            vars[name] = value;
        }
    }
    in.close();
}

// 清空记忆
void clearMemory() {
    vars.clear();
    std::remove(MEM_FILE.c_str());
    std::cout << "记忆已清空" << std::endl;
}

// ==================== 表达式计算 ====================
// 解析并计算 "1 * 365" 这样的表达式
int evaluate(const std::string& expr) {
    std::vector<std::string> tokens;
    std::string current;

    // 1. 词法分析：拆成 数字、运算符、变量名
    for (size_t i = 0; i < expr.length(); i++) {
        char c = expr[i];
        if (std::isdigit(c)) {
            current += c;
        } else if (std::isalpha(c)) {
            // 变量名（英文）
            current += c;
        } else if (c == '+' || c == '-' || c == '*' || c == '/') {
            if (!current.empty()) {
                tokens.push_back(current);
                current.clear();
            }
            tokens.push_back(std::string(1, c));
        } else if (c == ' ') {
            if (!current.empty()) {
                tokens.push_back(current);
                current.clear();
            }
        }
    }
    if (!current.empty()) tokens.push_back(current);

    // 2. 把变量名替换成它的值
    for (auto& token : tokens) {
        if (std::isalpha(token[0])) {
            if (vars.find(token) != vars.end()) {
                token = std::to_string(vars[token]);
            } else {
                std::cout << "错误：变量 " << token << " 未定义" << std::endl;
                return 0;
            }
        }
    }

    // 3. 先算乘除
    for (size_t i = 0; i < tokens.size(); i++) {
        if (tokens[i] == "*" || tokens[i] == "/") {
            int a = std::stoi(tokens[i - 1]);
            int b = std::stoi(tokens[i + 1]);
            int result = (tokens[i] == "*") ? (a * b) : (a / b);
            tokens[i - 1] = std::to_string(result);
            tokens.erase(tokens.begin() + i, tokens.begin() + i + 2);
            i--;
        }
    }

    // 4. 再算加减
    int result = std::stoi(tokens[0]);
    for (size_t i = 1; i < tokens.size(); i += 2) {
        int b = std::stoi(tokens[i + 1]);
        if (tokens[i] == "+") result += b;
        else if (tokens[i] == "-") result -= b;
    }

    return result;
}

// ==================== 主程序 ====================
int main() {
    // 启动时加载记忆
    loadMemory();
    if (!vars.empty()) {
        std::cout << "已加载上次的记忆（共 " << vars.size() << " 个变量）" << std::endl;
    }

    std::string line;

    // REPL 循环
    while (true) {
        std::cout << "L++ > ";
        std::getline(std::cin, line);

        if (line.empty()) continue;

        // 退出
        if (line == "exit") {
            std::cout << "再见！" << std::endl;
            break;
        }

        // 清空记忆
        if (line == "清空记忆") {
            clearMemory();
            continue;
        }

        // 变量声明：设 a = 1
        if (line.find("设 ") == 0) {
            size_t eq_pos = line.find('=');
            if (eq_pos != std::string::npos) {
                std::string name = line.substr(2, eq_pos - 2);
                // 去掉空格
                name.erase(0, name.find_first_not_of(" "));
                name.erase(name.find_last_not_of(" ") + 1);

                std::string value_str = line.substr(eq_pos + 1);
                value_str.erase(0, value_str.find_first_not_of(" "));
                value_str.erase(value_str.find_last_not_of(" ") + 1);

                try {
                    int value = evaluate(value_str);
                    vars[name] = value;
                    saveMemory();
                    std::cout << "已设置 " << name << " = " << value << std::endl;
                } catch (...) {
                    std::cout << "错误：无法解析值" << std::endl;
                }
            }
            continue;
        }

        // 打印：打印 "内容"
        if (line.find("打印 ") == 0) {
            std::string content = line.substr(3);
            // 去掉前后空格
            content.erase(0, content.find_first_not_of(" "));
            content.erase(content.find_last_not_of(" ") + 1);

            // 如果是双引号包起来的，就去掉引号
            if (content.length() >= 2 && content.front() == '"' && content.back() == '"') {
                content = content.substr(1, content.length() - 2);
            }
            std::cout << content << std::endl;
            continue;
        }

        // 表达式计算：1 + 1 或 a * 365
        try {
            int result = evaluate(line);
            std::cout << result << std::endl;
        } catch (...) {
            std::cout << "看不懂这个命令：" << line << std::endl;
        }
    }

    return 0;
}