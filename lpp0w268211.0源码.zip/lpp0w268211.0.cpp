#include <iostream>
#include <string>

int main() {
    std::string input;
    std::cout << "L++ > ";
    std::getline(std::cin, input);

    // 暂时只认 "1 + 1" 这种格式
    // 先找到 "+" 的位置
    size_t pos = input.find('+');
    if (pos != std::string::npos) {
        // 把 "+" 前后切成两半
        std::string left = input.substr(0, pos);
        std::string right = input.substr(pos + 1);
        
        // 转成整数，相加
        int a = std::stoi(left);
        int b = std::stoi(right);
        std::cout << a + b << std::endl;
    } else {
        std::cout << "看不懂，暂时只支持加法。" << std::endl;
    }
    return 0;
  std::cout << "按回车键退出..." << std::endl;
    std::cin.get();  // 等一个回车
    
    return 0;
}